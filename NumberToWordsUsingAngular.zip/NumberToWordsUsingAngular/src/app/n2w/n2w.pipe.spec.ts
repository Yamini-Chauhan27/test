/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { N2wPipe } from './n2w.pipe';

describe('Pipe: N2we', () => {
  it('create an instance', () => {
    let pipe = new N2wPipe();
    expect(pipe).toBeTruthy();
  });
});

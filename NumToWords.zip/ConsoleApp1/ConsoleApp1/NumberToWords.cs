﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    public interface NumberToWords
    {
        string ConvertNumbertoWords(Int64 number);
    }
}
